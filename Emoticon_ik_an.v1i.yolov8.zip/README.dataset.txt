# Emoticon_ik_an > 2023-11-02 9:55pm
https://universe.roboflow.com/project-5xdik/emoticon_ik_an

Provided by a Roboflow user
License: CC BY 4.0

